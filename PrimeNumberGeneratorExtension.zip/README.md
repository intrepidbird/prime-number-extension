# Prime Number Generator Extension

An extension that generates a prime number based on user input.

## How to Install

1. Download this code to your machine.

2. Open Google Chrome and go to `chrome://extensions`.

3. Enable Developer mode by toggling the switch in the top-right corner.

4. Click on "Load unpacked" button and select the "PrimeNumberGeneratorExtension" folder.

5. The extension should now appear in your extensions list and be ready for use.

## How to Use

1. After installing the extension, click on the extension icon in the top-right corner of Chrome.

2. The extension popup will open, displaying a form to enter a number.

3. Enter a number greater than 1 in the input field and click "Generate Prime".

4. The result will be displayed below the form, indicating whether the entered number is prime or not.

## How to Test

To test the extension locally, follow the "How to Install" instructions above. Once installed, click on the extension icon, enter different numbers in the input field, and verify that the correct prime number result is displayed.

## How to Develop

1. Make changes to the extension files as needed.

2. To see the changes, go to `chrome://extensions` and click on the "Refresh" button for the Prime Number Generator Extension.

3. Test the changes by clicking on the extension icon, entering different numbers, and ensuring the correct prime number result is displayed.

## How to Distribute

To distribute the extension, you need to package it as a .crx file. This can be done through the Chrome Web Store developer dashboard. Refer to the [official Chrome extension distribution guide](https://developer.chrome.com/docs/extensions/mv3/hosting/) for more details.

## Next Steps

Here are some possible next steps to improve the extension:

- Add additional functionality, such as generating a list of prime numbers within a given range.
- Implement error handling for invalid user input.
- Improve the user interface with styling and animations.

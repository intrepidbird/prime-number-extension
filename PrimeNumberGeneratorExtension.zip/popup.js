document.addEventListener('DOMContentLoaded', () => {
  const primeForm = document.getElementById('prime-form');
  const resultContainer = document.getElementById('result-container');

  primeForm.addEventListener('submit', (event) => {
    event.preventDefault();
    resultContainer.textContent = '';

    const numberInput = document.getElementById('number-input');
    const number = parseInt(numberInput.value);

    if (isNaN(number) || number <= 1) {
      resultContainer.textContent = 'Please enter a valid number greater than 1.';
      return;
    }

    const isPrime = checkPrime(number);

    if (isPrime) {
      resultContainer.textContent = `${number} is a prime number.`;
    } else {
      resultContainer.textContent = `${number} is not a prime number.`;
    }
  });

  function checkPrime(number) {
    for (let i = 2, sqrt = Math.sqrt(number); i <= sqrt; i++) {
      if (number % i === 0) {
        return false;
      }
    }
    return number > 1;
  }
});
